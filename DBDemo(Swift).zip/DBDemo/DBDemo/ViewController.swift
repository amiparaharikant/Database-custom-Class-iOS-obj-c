//
//  ViewController.swift
//  DBDemo
//
//  Created by Mac on 18/12/17.
//  Copyright © 2017 Mac. All rights reserved.
//

import UIKit

class ViewController: UIViewController {

    var getArr = NSMutableArray()
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        //Select
        let q = "Select * From AlbumDetail"
        getArr = Database.executeQuery(q)
        print(getArr)
//        //Insert
//        let query = "INSERT INTO AlbumDetail (Title,Title_Cover,Title_Bool,Title_Password) VALUES (\"\("\(TF_Title.text)")\",\"\("\(TF_Title.text)\(TF_Title.text)\(1).jpeg")\",\"\("\(TitleBoll)")\",\"\(TitlePass)\");"
//        getArr = Database.executeQuery(query)
    
//        //UPDATE
//        let query = "UPDATE NoteDetail SET  Title ='\("\(TF_title.text)")',Note='\("\(textview.text)")' where Title=='\(Str)'"
//        Database.executeScalarQuery(query)
        
//        //Delete
//        let q1 = "Delete From Capture_Image_Table where ID='\(idcontact)'"
//        getArr = Database.executeQuery(q)
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
}
